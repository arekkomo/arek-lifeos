---
name: context-switch
description: Automatically preserve session context and route to the correct bucket when the user changes topics.
---

# Context Switch & Topic Routing

Automatically preserve session context and route to the correct bucket when the user changes topics.

## Triggers

Auto-route 95% of input. If confidence < 95%, explicitly pause and ask which prefix to use.

**Topic Switch triggers (automatic):**
- "switch to [topic]"
- "new subject"
- "starting to [action]"
- "working on [new thing]"

**Task-specific prefixes (auto-detected):**
- "morning" → run Emily briefing
- "briefing" → run briefing
- "write" → content creation / docs
- "code" → software dev
- "research" → research / blogwatcher
- "news" → collect headlines + AI VFX pipeline scan
- "email" → email tasks
- "todo" → todo management
- "file" → file/vault operations

## Context Preservation

### Auto-routing
When any trigger fires, before doing anything else:

1. Check if there's active work in this session that should be preserved.
2. Write a quick snapshot to `PROJECTS/SESSIONS/YYYY-MM-DD-[topic].md` summarizing:
   - What was being worked on
   - Current state
   - What's pending next
   - Key decisions made
3. Then proceed with the requested task.

### Manual context switching
When user says "switch to [topic]" or "saving context for [topic]":

1. Read the current conversation state (via session_search or active context).
2. Commit to `PROJECTS/SESSIONS/YYYY-MM-DD-[topic].md`
3. Confirm to user: "Context saved for [topic]. Ready when you are."

## Session Snapshots

Location: `PROJECTS/SESSIONS/`

Format:
```markdown
# YYYY-MM-DD-[topic]
**Date:** YYYY-MM-DD
**State:** active / paused
**Summary:** [one-line summary]

## What was happening
- [bullet points]

## Pending
- [next steps]

## Key decisions
- [choices made]
```

## Verification
- Always create the file and confirm it exists before saying "saved".
- Use session_search to verify prior snapshots exist by topic and date.
