# Coach Profile Setup Reference

Built 2026-06-06. Full pattern for building a health/fitness specialist profile.

## Files Created

| File | Purpose |
|------|---------|
| `~/.hermes/skills/hybrid-arch/coach-specialist/SKILL.md` | Specialist identity + context + rules |
| `~/.hermes/skills/coach-fitness-tracking/SKILL.md` | Fitness tracking skill (routine, splits, PRs) |
| `~/.hermes/skills/coach-nutrition-tracking/SKILL.md` | Nutrition tracking (macros, meal planning) |
| `~/.hermes/skills/coach-body-composition/SKILL.md` | Body comp visual analysis |
| `~/.hermes/skills/coach-sleep-recovery/SKILL.md` | Sleep latency intervention, recovery flags |
| `~/.hermes/skills/coach-health-intelligence/SKILL.md` | Research cross-check, B12/tenofovir monitoring |
| `~/.hermes/profiles/coach/config.yaml` | Profile config loading all 6 skills + vision + working_directory |
| `~/.hermes/profiles/coach/SKILL.md` | Profile-level context wrapper |

## Config YAML Pattern

```yaml
name: coach
description: "Isolated fitness, health, nutrition, and recovery specialist for Arek Komorowski."
skills:
  - hybrid-arch:coach-specialist
  - coach-fitness-tracking
  - coach-nutrition-tracking
  - coach-body-composition
  - coach-sleep-recovery
  - coach-health-intelligence
model: {}
deliver: origin
toolsets:
  - file
  - search
  - vision
working_directory: /home/realityrove/Obsidian/Arek&Co
```

### Key fields
- **`toolsets: [vision]`** — needed if agent analyzes food/body photos
- **`working_directory`** — sets base path for vault file resolution

## Visible Identity Marker (Required)

Coach responses start with `Coach:` prefix. This is non-negotiable — without it, there's no way for the user to distinguish which profile is responding.

Add this to any specialist's SKILL.md to enforce:
> "Every response begins with: `{name}: ` prefix. Never omit it."

For Coach specifically: `Coach: ` (followed by the response).

## Vault Docs Are Often Stubs

Vault SKILLS/ SK-CO-XX files are placeholder summaries. The real detailed instructions live in `AGENTS/<Agent>/CoWork-Instructions.md`. Always use the full instructions when building Hermes skills.
